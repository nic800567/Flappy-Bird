kaboom()

loadBean()
loadSprite("enemy","images.png")
loadSprite("flappy","images (2).png")

scene ("game", () => {
  


let score = 0
const SPEED = 320
const PIPE_OPEN = 240
const PIPE_MIN = 60
const CEILING = -60
let RIGHT = 250
const jump = 800
let gravity = 3200
//let h1 = rand(200)
//let h2 = rand(50)

const player = add([
  sprite("bean"), //image
  pos(50,50), //position
  body(), //gravity
  area(), //collision
])

let scoreLabel = add([
  text("Score: 0"),
  pos(170,0),
  z(1),
  fixed,
])

onKeyPress("space",() => {
  player.jump(jump)
})
//kaboomjs
const h1 = rand(PIPE_MIN, height() - PIPE_MIN - PIPE_OPEN)
const h2 = height() - h1 - PIPE_OPEN

	// kaboomjs
function spawnPipe() {
add([
  pos(width(), 0),
  rect(64, h1),
  color(0, 127, 255),
  outline(4),
  area(),
  move(LEFT, SPEED),
  cleanup(),
  // give it tags to easier define behaviors see below
  "pipe",
])
add([
  pos(width(), h1 + PIPE_OPEN),
  rect(64, h2),
  color(0, 127, 255),
  outline(4),
  area(),
  move(LEFT, SPEED),
  cleanup(),
  // give it tags to easier define behaviors see below
  "pipe",
  // raw obj just assigns every field to the game obj
  { passed: false, },
 ])
}
  onUpdate("pipe", (p) => {
		// check if bean passed the pipe
		if (p.pos.x + p.width <= player && p.passed === false) {
			addScore()
			p.passed = true
		}
	})
  loop (1, () => {
    spawnPipe()
  })
})

/*onKeyDown("space",() => {
     pos(player.pos)
    
})*/

  
  







scene ("lose", () => {
  add([
		text("score: "),
		pos(width() / 2, height() / 2 + 108),
		origin("center"),
	])

	// go back to game with space is pressed
	onKeyPress("space", () => go("game"))
	onClick(() => go("game"))

})
	
go ("game")




  
  
  
  
  